import React, { useState } from 'react';
import { Plus, Layers, BarChart2, ChevronRight, User } from 'lucide-react';

export type TabType = 'my_actions' | 'profile' | string;

interface UnifiedOverlayLayoutProps {
  children: React.ReactNode;
  title: string;
  roleSwitcher: React.ReactNode;
  avatarPanel: React.ReactNode;
  workflowOptions: string[];
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  onGoHome?: () => void;
}

export function UnifiedOverlayLayout({
  children,
  title,
  roleSwitcher,
  avatarPanel,
  workflowOptions,
  activeTab,
  onTabChange,
  onGoHome,
}: UnifiedOverlayLayoutProps) {
  const [isWorkflowOpen, setIsWorkflowOpen] = useState(false);

  const toggleWorkflow = () => setIsWorkflowOpen(!isWorkflowOpen);

  const handleWorkflowOptionClick = (option: string) => {
    onTabChange(option);
    // On mobile we might want to close the menu, but for now let's keep it simple
    setIsWorkflowOpen(false); 
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col md:flex-row bg-surface-grey">
      
      {/* --- PC Sidebar (Left) --- */}
      <div className="hidden md:flex flex-col w-20 lg:w-64 h-screen sticky top-0 border-r border-white/50 bg-white/40 backdrop-blur-md p-4 z-30 justify-center gap-8">
        
        {/* My Actions Button */}
        <button 
          onClick={() => onTabChange('my_actions')}
          className={`w-full aspect-square lg:aspect-auto lg:p-4 rounded-2xl flex items-center justify-center lg:justify-start gap-3 transition-all duration-200 ${activeTab === 'my_actions' ? 'bg-black text-white shadow-md' : 'bg-white hover:bg-neutral-50 text-neutral-600 shadow-sm'}`}
          title="My Actions"
        >
          <Layers size={24} />
          <span className="font-bold text-sm hidden lg:block">My Actions</span>
        </button>

        {/* Workspace Section */}
        <div className="relative w-full">
           <button 
              onClick={toggleWorkflow}
              className={`w-full aspect-square lg:aspect-auto lg:p-4 rounded-2xl flex items-center justify-center lg:justify-between gap-3 transition-all duration-200 ${isWorkflowOpen || workflowOptions.includes(activeTab) ? 'bg-neon-lime text-black shadow-md border border-black/10' : 'bg-white hover:bg-neutral-50 text-neutral-600 shadow-sm'}`}
              title="Workspace"
            >
              <div className="flex items-center gap-3">
                <Plus size={24} strokeWidth={2.5} className={`transition-transform duration-300 ${isWorkflowOpen ? 'rotate-45' : ''}`} />
                <span className="font-bold text-sm uppercase tracking-wide hidden lg:block">Workspace</span>
              </div>
            </button>
            
            {/* Workflow Menu Expansion - Right Side Ring/Arc Style (Reverted) */}
            {isWorkflowOpen && (
              <div className="absolute left-full top-1/2 -translate-y-1/2 ml-6 flex flex-col gap-2 min-w-[200px] animate-in slide-in-from-left-4 fade-in duration-200">
                {/* Decorative Connector */}
                <div className="absolute -left-6 top-1/2 -translate-y-1/2 w-6 h-0.5 bg-neon-lime/50"></div>
                <div className="absolute -left-1 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-neon-lime"></div>

                <div className="bg-white/80 backdrop-blur-xl p-2 rounded-[2rem] shadow-2xl border border-white/50 flex flex-col gap-1">
                  {workflowOptions.map((option, idx) => (
                    <button 
                      key={idx}
                      onClick={() => handleWorkflowOptionClick(option)}
                      className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-between group ${activeTab === option ? 'bg-black text-white shadow-lg' : 'text-neutral-600 hover:bg-neutral-100'}`}
                    >
                      {option}
                      {activeTab === option && <ChevronRight size={14} />}
                    </button>
                  ))}
                </div>
              </div>
            )}
        </div>

        {/* Profile Button */}
        <button 
          onClick={() => onTabChange('profile')}
          className={`w-full aspect-square lg:aspect-auto lg:p-4 rounded-2xl flex items-center justify-center lg:justify-start gap-3 transition-all duration-200 ${activeTab === 'profile' ? 'bg-black text-white shadow-md' : 'bg-white hover:bg-neutral-50 text-neutral-600 shadow-sm'}`}
          title="Profile"
        >
          <BarChart2 size={24} />
          <span className="font-bold text-sm hidden lg:block">Profile</span>
        </button>
      </div>

      {/* --- Main Content Area --- */}
      <div className="flex-1 flex flex-col min-h-screen relative">
        {/* New Global Header */}
        <div className="sticky top-0 flex items-center justify-between px-6 py-4 bg-white/50 backdrop-blur-md border-b border-white/50 z-20">
          
          {/* Left: Breadcrumbs & Role Switcher */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm font-medium text-neutral-500">
              <button onClick={onGoHome} className="hover:text-black transition-colors">Home</button>
              <span className="text-neutral-300">/</span>
              <span className="text-neutral-900 font-bold">{title}</span>
            </div>
            
            {/* Integrated Role Switcher */}
            <div className="h-6 w-px bg-neutral-200 mx-2"></div>
            {roleSwitcher}
          </div>

          {/* Right: Avatar */}
          <div>{avatarPanel}</div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 p-6 pb-32 md:pb-6">
          {children}
        </div>
      </div>

      {/* --- Mobile Bottom Bar --- */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50">
        
        {/* Mobile Workflow Menu Overlay */}
        {isWorkflowOpen && (
          <div className="absolute bottom-24 left-4 right-4 z-50 animate-in slide-in-from-bottom-4 fade-in duration-200">
             <div className="fixed inset-0 bg-black/20 backdrop-blur-sm -z-10" onClick={() => setIsWorkflowOpen(false)} />
             <div className="bg-white rounded-[2rem] p-2 shadow-2xl border border-white/50 space-y-1">
                {workflowOptions.map((option, idx) => (
                <button 
                  key={idx}
                  onClick={() => handleWorkflowOptionClick(option)}
                  className={`w-full text-left px-6 py-4 hover:bg-neutral-50 rounded-2xl text-base font-bold flex items-center justify-between ${activeTab === option ? 'bg-neutral-100 text-black' : 'text-neutral-900'}`}
                >
                  {option}
                  <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center">
                    <ChevronRight size={16} />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Bottom Navigation Bar */}
        <div className="bg-white border-t border-white/50 px-6 py-4 pb-8 shadow-[0_-4px_20px_rgba(0,0,0,0.05)] flex items-center justify-between gap-4 pointer-events-auto">
          
          <button 
            onClick={() => onTabChange('my_actions')}
            className={`flex-1 flex flex-col items-center gap-1 transition-colors ${activeTab === 'my_actions' ? 'text-black' : 'text-neutral-400'}`}
          >
            <div className={`p-3 rounded-2xl ${activeTab === 'my_actions' ? 'bg-neutral-100' : 'bg-transparent'}`}>
              <Layers size={24} strokeWidth={activeTab === 'my_actions' ? 2.5 : 2} />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wide">Actions</span>
          </button>

          <div className="relative -top-8">
            <button 
              onClick={toggleWorkflow}
              className={`w-16 h-16 rounded-full shadow-xl flex items-center justify-center border-4 border-surface-grey transition-transform active:scale-95 ${isWorkflowOpen ? 'bg-neon-lime text-black' : 'bg-black text-neon-lime'}`}
            >
              <Plus size={32} strokeWidth={2.5} className={`transition-transform duration-300 ${isWorkflowOpen ? 'rotate-45' : ''}`} />
            </button>
          </div>

          <button 
            onClick={() => onTabChange('profile')}
            className={`flex-1 flex flex-col items-center gap-1 transition-colors ${activeTab === 'profile' ? 'text-black' : 'text-neutral-400'}`}
          >
            <div className={`p-3 rounded-2xl ${activeTab === 'profile' ? 'bg-neutral-100' : 'bg-transparent'}`}>
              <BarChart2 size={24} strokeWidth={activeTab === 'profile' ? 2.5 : 2} />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wide">Profile</span>
          </button>

        </div>
      </div>

    </div>
  );
}
