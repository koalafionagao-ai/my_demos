import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  currentScreen: number;
  onScreenChange: (screen: number) => void;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-surface-grey font-sans text-neutral-900 selection:bg-black selection:text-neon-lime">
      {/* Main Content Area */}
      <main className="min-h-screen w-full">
        {children}
      </main>
    </div>
  );
}
