import React, { useState } from 'react';
import { QrCode, Mail, MessageSquare, Smartphone, Eye, ArrowLeft, Check, Share2, Copy } from 'lucide-react';

interface ConnectViewProps {
  role: 'D2C' | 'Dealership';
  userName?: string;
  userTitle?: string;
}

type ConnectMethod = 'qr' | 'email' | 'sms';
type LeadSource = 'Walk-in' | 'Event' | 'Outbound';

export function ConnectView({ role, userName = "Sam Parker", userTitle }: ConnectViewProps) {
  const [activeMethod, setActiveMethod] = useState<ConnectMethod>('qr');
  const [source, setSource] = useState<LeadSource>('Walk-in');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [isSent, setIsSent] = useState(false);

  // Determine available sources based on role
  const availableSources: LeadSource[] = role === 'Dealership' 
    ? ['Walk-in', 'Event', 'Outbound'] 
    : ['Walk-in', 'Event'];

  const handleSend = () => {
    // Simulate sending
    setIsSent(true);
    setTimeout(() => setIsSent(false), 3000);
  };

  if (showPreview) {
    return (
      <div className="max-w-md mx-auto bg-white min-h-[600px] rounded-3xl shadow-2xl border-8 border-neutral-900 overflow-hidden relative animate-in slide-in-from-bottom-4 duration-300">
        <div className="absolute top-0 left-0 right-0 h-32 bg-neutral-900"></div>
        <div className="relative pt-8 px-6 pb-6 flex flex-col items-center text-center">
          
          {/* Luxury Logo - Consistent with Global */}
          <div className="flex items-center gap-2 mb-6 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
            <div className="w-6 h-6 bg-black rounded-lg flex items-center justify-center shadow-sm">
              <span className="text-white font-serif font-bold text-xs">L</span>
            </div>
            <span className="text-sm font-bold text-white tracking-tight">Luxury</span>
          </div>

          <div className="w-24 h-24 rounded-full border-4 border-white bg-neutral-200 shadow-lg mb-4 flex items-center justify-center text-3xl font-bold text-neutral-500">
            {userName.charAt(0)}
          </div>

          <h2 className="text-2xl font-bold text-neutral-900">{userName}</h2>
          <p className="text-sm text-neutral-500 uppercase tracking-wide mb-6">{userTitle || (role === 'D2C' ? 'Client Advisor' : 'Sales Consultant')}</p>
          
          <div className="w-full space-y-3">
            <button className="w-full py-3 bg-black text-white rounded-xl font-bold shadow-lg hover:bg-neutral-800 transition-all flex items-center justify-center gap-2">
              <MessageSquare size={18} />
              Chat with me
            </button>
            <button className="w-full py-3 bg-white border border-neutral-200 text-neutral-900 rounded-xl font-bold hover:bg-neutral-50 transition-all flex items-center justify-center gap-2">
              <Smartphone size={18} />
              Schedule Call
            </button>
            <button className="w-full py-3 bg-white border border-neutral-200 text-neutral-900 rounded-xl font-bold hover:bg-neutral-50 transition-all flex items-center justify-center gap-2">
              <Mail size={18} />
              Email Me
            </button>
          </div>

          <div className="mt-8 p-4 bg-neutral-50 rounded-2xl w-full text-left">
            <h3 className="text-xs font-bold text-neutral-400 uppercase mb-2">About Luxury</h3>
            <p className="text-sm text-neutral-600 leading-relaxed mb-4">
              We are redefining the future of mobility with sustainable, high-performance electric vehicles designed for the modern world.
            </p>
            <h3 className="text-xs font-bold text-neutral-400 uppercase mb-2">About Me</h3>
            <p className="text-sm text-neutral-600 leading-relaxed">
              Passionate about electric mobility and helping you find the perfect vehicle. Let's start your journey today.
            </p>
          </div>
        </div>
        
        <button 
          onClick={() => setShowPreview(false)}
          className="absolute top-4 left-4 bg-white/20 backdrop-blur-md text-white p-2 rounded-full hover:bg-white/30 transition-all"
        >
          <ArrowLeft size={20} />
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto animate-in fade-in duration-300 h-full flex flex-col justify-center">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-neutral-900 mb-2">Connect with Customer</h2>
        <p className="text-neutral-500">Share your digital business card to create a new lead.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 items-stretch">
        {/* Left Column: Unified Card (Business Card Config) */}
        <div className="lg:col-span-2 bg-white p-6 lg:p-8 rounded-3xl shadow-sm border border-neutral-100 flex flex-col h-full">
          
          {/* Method Tabs */}
          <div className="bg-neutral-100 p-1.5 rounded-2xl flex mb-4">
            <button 
              onClick={() => setActiveMethod('qr')}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeMethod === 'qr' ? 'bg-white shadow-sm text-black' : 'text-neutral-500 hover:text-neutral-700'}`}
            >
              <QrCode size={16} />
              QR Scan
            </button>
            <button 
              onClick={() => setActiveMethod('email')}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeMethod === 'email' ? 'bg-white shadow-sm text-black' : 'text-neutral-500 hover:text-neutral-700'}`}
            >
              <Mail size={16} />
              Email
            </button>
            <button 
              onClick={() => setActiveMethod('sms')}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${activeMethod === 'sms' ? 'bg-white shadow-sm text-black' : 'text-neutral-500 hover:text-neutral-700'}`}
            >
              <MessageSquare size={16} />
              SMS
            </button>
          </div>

          {/* Source Selection */}
          <div className="mb-4">
            <h3 className="text-[10px] font-bold text-neutral-500 uppercase mb-2 tracking-wider">Lead Source</h3>
            <div className="flex flex-wrap gap-2">
              {availableSources.map(s => (
                <button
                  key={s}
                  onClick={() => setSource(s)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-bold border transition-all flex items-center gap-1.5 ${source === s ? 'bg-black text-white border-black shadow-md' : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'}`}
                >
                  {source === s && <Check size={14} />}
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 flex flex-col items-center justify-center text-center min-h-[240px] border-t border-neutral-100 pt-4">
            {activeMethod === 'qr' && (
              <div className="space-y-3 animate-in zoom-in-95 duration-300">
                <div className="bg-white p-1.5 rounded-2xl shadow-xl border border-neutral-100 inline-block transform hover:scale-105 transition-transform duration-300">
                  {/* Placeholder QR Code */}
                  <div className="w-40 h-40 bg-neutral-900 rounded-xl flex items-center justify-center text-white relative overflow-hidden">
                    <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white to-transparent"></div>
                    <QrCode size={110} />
                    <div className="absolute bottom-2 left-0 right-0 text-center text-[8px] font-mono opacity-50 tracking-widest">{source.toUpperCase()} TRACKING</div>
                  </div>
                </div>
                <div>
                  <p className="text-base font-bold text-neutral-900">Scan to connect</p>
                  <p className="text-xs text-neutral-500 mt-0.5">Source: <span className="font-bold text-black">{source}</span></p>
                </div>
              </div>
            )}

            {activeMethod === 'email' && (
              <div className="w-full max-w-sm space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="text-left">
                  <label className="text-sm font-bold text-neutral-900 mb-2 block">Customer Email</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full p-4 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-black text-lg"
                  />
                </div>
                <button 
                  onClick={handleSend}
                  disabled={!email || isSent}
                  className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg ${isSent ? 'bg-green-500 text-white' : 'bg-black text-white hover:bg-neutral-800 hover:shadow-xl hover:-translate-y-0.5'}`}
                >
                  {isSent ? <Check size={20} /> : <Mail size={20} />}
                  {isSent ? 'Invitation Sent!' : 'Send Invitation'}
                </button>
                <p className="text-xs text-neutral-400">Will send a personalized link tracked as <span className="font-bold">{source}</span></p>
              </div>
            )}

            {activeMethod === 'sms' && (
              <div className="w-full max-w-sm space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="text-left">
                  <label className="text-sm font-bold text-neutral-900 mb-2 block">Customer Mobile</label>
                  <input 
                    type="tel" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(555) 000-0000"
                    className="w-full p-4 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-black text-lg"
                  />
                </div>
                <button 
                  onClick={handleSend}
                  disabled={!phone || isSent}
                  className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg ${isSent ? 'bg-green-500 text-white' : 'bg-black text-white hover:bg-neutral-800 hover:shadow-xl hover:-translate-y-0.5'}`}
                >
                  {isSent ? <Check size={20} /> : <MessageSquare size={20} />}
                  {isSent ? 'Invitation Sent!' : 'Send Invitation'}
                </button>
                <p className="text-xs text-neutral-400">Will send a personalized link tracked as <span className="font-bold">{source}</span></p>
              </div>
            )}
          </div>

        </div>

        {/* Right Column: Preview (1/3 width) */}
        <div className="bg-neutral-900 text-white p-8 rounded-3xl shadow-2xl relative overflow-hidden group flex flex-col justify-between h-full">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:bg-white/10 transition-all duration-700"></div>
            
            {/* Top Section */}
            <div className="relative z-10">
              <div className="flex items-center gap-4">
                 <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center text-2xl font-bold border-2 border-white/20">
                    {userName.charAt(0)}
                 </div>
                 <div>
                   <h3 className="text-xl font-bold">{userName}</h3>
                   <p className="text-neutral-400 text-sm">{userTitle || (role === 'D2C' ? 'Client Advisor' : 'Sales Consultant')}</p>
                 </div>
              </div>
            </div>

            {/* Middle Section */}
            <div className="relative z-10">
              <div className="bg-white/10 rounded-2xl p-5 backdrop-blur-sm border border-white/5">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center shadow-sm">
                    <span className="text-white font-serif font-bold text-xs">L</span>
                  </div>
                  <span className="font-bold">Luxury Digital Card</span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  This is what your customer will see when they scan the QR code or click the link. It includes your contact info and a direct line to chat.
                </p>
              </div>
            </div>
            
            {/* Bottom Section */}
            <div className="relative z-10">
              <button 
                onClick={() => setShowPreview(true)}
                className="w-full bg-white text-black py-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 hover:bg-neutral-200 transition-colors shadow-lg"
              >
                <Eye size={16} />
                Open Full Preview
              </button>
            </div>
        </div>

      </div>
    </div>
  );
}
