import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Phone, MessageSquare, ChevronRight, AlertCircle, CheckCircle2, Car, FileText, ArrowRight, MoreHorizontal, Filter } from 'lucide-react';

interface Appointment {
  id: string;
  time: string;
  type: 'test_drive' | 'configuration' | 'deal_review' | 'handover';
  customer: string;
  vehicle?: string;
  status: 'completed' | 'in_progress' | 'upcoming' | 'next';
  location: string;
}

interface Task {
  id: string;
  category: 'connect' | 'config' | 'test_drive' | 'quote' | 'finance' | 'trade_in' | 'order' | 'handover';
  title: string;
  customer: string;
  pendingTime: string;
  priority: 'high' | 'medium' | 'low';
  isAlert?: boolean;
}

const MOCK_APPOINTMENTS: Appointment[] = [
  { id: '1', time: '09:00 AM', type: 'test_drive', customer: 'John Doe', vehicle: 'Apex GT Performance', status: 'completed', location: 'Showroom' },
  { id: '2', time: '11:00 AM', type: 'configuration', customer: 'Sarah Smith', vehicle: 'Summit SUV Long Range', status: 'in_progress', location: 'Design Studio' },
  { id: '3', time: '02:00 PM', type: 'deal_review', customer: 'Mike Johnson', vehicle: 'Titan Truck', status: 'next', location: 'Finance Office' },
  { id: '4', time: '04:30 PM', type: 'handover', customer: 'Emily Davis', vehicle: 'Spectra Sedan Plaid', status: 'upcoming', location: 'Delivery Bay' },
];

const MOCK_TASKS: Task[] = [
  { id: 't1', category: 'connect', title: 'New Lead (Scan)', customer: 'David Wilson', pendingTime: 'Pending: 49h', priority: 'high', isAlert: true },
  { id: 't2', category: 'connect', title: 'New Lead (Scan)', customer: 'Walk-in Customer 1', pendingTime: 'Pending: 2h', priority: 'medium' },
  { id: 't3', category: 'connect', title: 'New Lead (Scan)', customer: 'Event Guest 2', pendingTime: 'Pending: 5h', priority: 'medium' },
  { id: 't4', category: 'connect', title: 'New Lead (Scan)', customer: 'Online Inquiry', pendingTime: 'Due in: 1d', priority: 'low' },
  { id: 't5', category: 'config', title: 'Send Config Email', customer: 'Alice Brown', pendingTime: 'Pending: 4h', priority: 'medium' },
  { id: 't6', category: 'config', title: 'Send Config Email', customer: 'Bob White', pendingTime: 'Pending: 6h', priority: 'medium' },
  { id: 't7', category: 'trade_in', title: 'Trade-in Approval', customer: 'Charlie Green', pendingTime: 'Due in: 1d', priority: 'high' },
  { id: 't8', category: 'quote', title: 'Send Quote', customer: 'Fiona Hill', pendingTime: 'Pending: 3h', priority: 'high' },
  { id: 't9', category: 'finance', title: 'Finance Application', customer: 'George Baker', pendingTime: 'Pending: 1h', priority: 'medium' },
];

const SLOT_STATUS = [
  { model: 'Apex GT', available: 2, total: 4 },
  { model: 'Summit SUV', available: 1, total: 3 },
  { model: 'Spectra Sedan', available: 0, total: 2, nextFree: '5:00 PM' },
  { model: 'Horizon EV', available: 1, total: 2 },
];

export function SalesDashboard({ role, userName }: { role: 'D2C' | 'Dealership'; userName: string }) {
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(new Date().getDay() === 0 ? 6 : new Date().getDay() - 1); // Default to today (Mon=0...Sun=6)

  const weekDays = [
    { name: 'Mon', date: 'Feb 23' },
    { name: 'Tue', date: 'Feb 24' },
    { name: 'Wed', date: 'Feb 25' },
    { name: 'Thu', date: 'Feb 26' },
    { name: 'Fri', date: 'Feb 27' },
    { name: 'Sat', date: 'Feb 28' },
    { name: 'Sun', date: 'Mar 01' },
  ];

  const getDayAppointments = (index: number) => {
    switch(index) {
      case 0: return MOCK_APPOINTMENTS; // 4
      case 2: return MOCK_APPOINTMENTS.slice(0, 3); // 3
      case 3: return MOCK_APPOINTMENTS.slice(2, 3); // 1
      case 4: return MOCK_APPOINTMENTS.slice(1, 3); // 2
      default: return [];
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-500">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-neutral-900">Good Afternoon, {userName.split(' ')[0]}</h2>
          <p className="text-neutral-500">Here's your schedule for the week.</p>
        </div>
        <div className="flex items-center gap-3">
           {role === 'Dealership' && (
              <div className="flex items-center gap-2 text-xs font-bold text-blue-700 bg-blue-50 px-3 py-2 rounded-lg border border-blue-100">
                <Filter size={14} />
                Brand: Luxury
              </div>
            )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Appointments (Prominent) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Appointments Card */}
          <div className="bg-white rounded-3xl shadow-sm border border-neutral-100 overflow-hidden min-h-[500px]">
            <div className="p-6 border-b border-neutral-100 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-neutral-100 rounded-xl"><Calendar size={20} /></div>
                <h3 className="font-bold text-lg">Appointments</h3>
              </div>
              <div className="flex gap-2">
                <button className="flex items-center gap-2 px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-xs font-bold text-neutral-600 hover:bg-neutral-50 transition-colors">
                  <div className="w-4 h-4 bg-blue-600 rounded flex items-center justify-center text-[8px] text-white font-bold">O</div>
                  Outlook
                </button>
                <button className="flex items-center gap-2 px-3 py-1.5 bg-white border border-neutral-200 rounded-lg text-xs font-bold text-neutral-600 hover:bg-neutral-50 transition-colors">
                  <div className="w-4 h-4 bg-red-500 rounded flex items-center justify-center text-[8px] text-white font-bold">G</div>
                  Gmail
                </button>
              </div>
            </div>
            
            <div className="p-0">
              {/* Horizontal Day Selector */}
              <div className="flex border-b border-neutral-100 overflow-x-auto no-scrollbar bg-neutral-50/50">
                {weekDays.map((day, i) => {
                  const isSelected = selectedDayIndex === i;
                  const isToday = i === (new Date().getDay() === 0 ? 6 : new Date().getDay() - 1);
                  const dayApts = getDayAppointments(i);
                  const aptCount = dayApts.length;

                  return (
                    <button
                      key={day.name}
                      onClick={() => setSelectedDayIndex(i)}
                      className={`flex-1 min-w-[100px] py-4 px-2 flex flex-col items-center gap-1 transition-all relative ${
                        isSelected ? 'bg-white' : 'hover:bg-neutral-100/50'
                      }`}
                    >
                      <span className={`text-[10px] font-bold uppercase tracking-wider ${isSelected ? 'text-black' : 'text-neutral-400'}`}>
                        {day.name}
                      </span>
                      <div className="flex items-baseline gap-1">
                        <span className={`text-lg font-bold ${isSelected ? 'text-black' : 'text-neutral-600'}`}>
                          {day.date.split(' ')[1]}
                        </span>
                        {isToday && (
                          <span className="w-1.5 h-1.5 rounded-full bg-neon-lime mb-1"></span>
                        )}
                      </div>
                      <div className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        aptCount > 0 
                          ? (isSelected ? 'bg-black text-white' : 'bg-neutral-200 text-neutral-600') 
                          : 'text-neutral-300'
                      }`}>
                        {aptCount} {aptCount === 1 ? 'Apt' : 'Apts'}
                      </div>
                      
                      {isSelected && (
                        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-black"></div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Appointments Content */}
              <div className="p-6 min-h-[400px]">
                <div className="space-y-6">
                  {getDayAppointments(selectedDayIndex).length > 0 ? (
                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                      {getDayAppointments(selectedDayIndex).map((apt, index, arr) => (
                        <div key={apt.id} className={`relative pl-8 ${index !== arr.length - 1 ? 'pb-8 border-l border-neutral-100' : ''}`}>
                          {/* Timeline Dot */}
                          <div className={`absolute left-[-5px] top-0 w-2.5 h-2.5 rounded-full border-2 ${
                            apt.status === 'completed' ? 'bg-neutral-300 border-neutral-300' :
                            apt.status === 'next' ? 'bg-neon-lime border-black animate-pulse' :
                            'bg-white border-neutral-300'
                          }`}></div>

                          <div className={`p-4 rounded-2xl border transition-all ${
                            apt.status === 'next' ? 'bg-neutral-900 text-white shadow-lg scale-[1.02] border-neutral-900' : 
                            'bg-white border-neutral-100 hover:border-neutral-200'
                          }`}>
                            <div className="flex justify-between items-start mb-2">
                              <div className="flex items-center gap-2">
                                <Clock size={14} className={apt.status === 'next' ? 'text-neutral-400' : 'text-neutral-400'} />
                                <span className={`text-xs font-bold ${apt.status === 'next' ? 'text-neutral-300' : 'text-neutral-500'}`}>{apt.time}</span>
                                {apt.status === 'next' && (
                                  <span className="bg-neon-lime text-black text-[10px] font-bold px-2 py-0.5 rounded-full">Next Up</span>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <button className={`p-1.5 rounded-lg transition-colors ${apt.status === 'next' ? 'hover:bg-white/20 text-white' : 'hover:bg-neutral-100 text-neutral-400'}`}>
                                  <Phone size={16} />
                                </button>
                                <button className={`p-1.5 rounded-lg transition-colors ${apt.status === 'next' ? 'hover:bg-white/20 text-white' : 'hover:bg-neutral-100 text-neutral-400'}`}>
                                  <MessageSquare size={16} />
                                </button>
                              </div>
                            </div>
                            
                            <div className="flex items-start justify-between">
                              <div>
                                <h4 className="font-bold text-lg mb-1">{apt.customer}</h4>
                                <div className={`flex items-center gap-2 text-sm ${apt.status === 'next' ? 'text-neutral-400' : 'text-neutral-500'}`}>
                                  <span className="capitalize">{apt.type.replace('_', ' ')}</span>
                                  <span className="w-1 h-1 rounded-full bg-current opacity-50"></span>
                                  <span>{apt.vehicle}</span>
                                </div>
                              </div>
                              {apt.status === 'next' && (
                                <button className="bg-white text-black px-4 py-2 rounded-xl text-xs font-bold hover:bg-neutral-200 transition-colors">
                                  Start
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-20 text-neutral-400 animate-in fade-in duration-500">
                      <Calendar size={48} className="mb-4 opacity-20" />
                      <p className="italic">No appointments scheduled for this day.</p>
                      <button className="mt-4 text-xs font-bold text-black border-b border-black pb-0.5">View Full Calendar</button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Slot Management */}
          <div className="bg-white rounded-3xl shadow-sm border border-neutral-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-neutral-100 rounded-xl"><Car size={20} /></div>
              <h3 className="font-bold text-lg">Test Drive Slots</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {SLOT_STATUS.map((slot) => (
                <div key={slot.model} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-100 group hover:border-neutral-300 transition-all">
                  <div className="text-xs font-bold text-neutral-500 mb-2">{slot.model}</div>
                  <div className="flex items-end justify-between mb-3">
                    <div className="flex items-end gap-2">
                      <span className={`text-2xl font-bold ${slot.available === 0 ? 'text-neutral-300' : 'text-neutral-900'}`}>
                        {slot.available}
                      </span>
                      <span className="text-xs text-neutral-400 mb-1">/ {slot.total}</span>
                    </div>
                    {slot.available > 0 && (
                      <button className="p-1.5 bg-white border border-neutral-200 rounded-lg text-neutral-400 hover:text-black hover:border-black transition-all">
                        <ArrowRight size={14} />
                      </button>
                    )}
                  </div>
                  {slot.available === 0 && slot.nextFree && (
                    <div className="text-[10px] font-bold text-orange-600 bg-orange-50 px-2 py-1 rounded-md inline-block">
                      Next: {slot.nextFree}
                    </div>
                  )}
                  {slot.available > 0 && (
                    <button className="w-full text-[10px] font-bold text-green-600 bg-green-50 px-2 py-1.5 rounded-md hover:bg-green-100 transition-colors text-center">
                      Quick Reserve
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Task List */}
        <div className="space-y-6">
          
          <div className="bg-white rounded-3xl shadow-sm border border-neutral-100 overflow-hidden h-full">
            <div className="p-6 border-b border-neutral-100 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-neutral-100 rounded-xl"><CheckCircle2 size={20} /></div>
                <h3 className="font-bold text-lg">Task List</h3>
              </div>
              <span className="bg-black text-white text-xs font-bold px-2 py-1 rounded-md">{MOCK_TASKS.length} Pending</span>
            </div>

            <div className="p-4 space-y-6 overflow-y-auto max-h-[600px]">
              
              {/* Alerts Section */}
              {MOCK_TASKS.some(t => t.isAlert) && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-red-500 uppercase tracking-wide px-2">Urgent Alerts</h4>
                  {MOCK_TASKS.filter(t => t.isAlert).map(task => (
                    <div key={task.id} className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start gap-3 group cursor-pointer hover:shadow-md transition-all">
                      <div className="mt-1 text-red-500"><AlertCircle size={18} /></div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-1">
                          <span className="font-bold text-sm text-neutral-900">{task.title}</span>
                          <span className="text-[10px] font-bold bg-red-200 text-red-800 px-1.5 py-0.5 rounded flex items-center gap-1">
                            {task.pendingTime}
                          </span>
                        </div>
                        <p className="text-xs text-neutral-600 mb-2">Customer: <span className="font-bold">{task.customer}</span></p>
                        <button className="w-full py-1.5 bg-white border border-red-200 text-red-600 rounded-lg text-xs font-bold hover:bg-red-100 transition-colors">
                          Take Action
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Categories */}
              {(['connect', 'config', 'test_drive', 'quote', 'finance', 'trade_in', 'order', 'handover'] as const).map(category => {
                const tasks = MOCK_TASKS.filter(t => t.category === category && !t.isAlert);
                if (tasks.length === 0) return null;

                return (
                  <div key={category} className="space-y-3">
                    <div className="flex items-center justify-between px-2">
                      <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wide">{category.replace('_', ' ')}</h4>
                      <span className="text-xs font-bold text-neutral-300">{tasks.length}</span>
                    </div>
                    {tasks.map(task => (
                      <div key={task.id} className="p-4 bg-white border border-neutral-100 rounded-2xl hover:border-neutral-300 transition-all cursor-pointer group">
                        <div className="flex justify-between items-start mb-2">
                          <span className="font-bold text-sm text-neutral-900 group-hover:text-blue-600 transition-colors">{task.title}</span>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            task.priority === 'high' ? 'bg-orange-50 text-orange-700' : 'bg-neutral-100 text-neutral-500'
                          }`}>
                            {task.pendingTime}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-neutral-500">{task.customer}</p>
                          <ChevronRight size={14} className="text-neutral-300 group-hover:text-neutral-900 transition-colors" />
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })}

            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
