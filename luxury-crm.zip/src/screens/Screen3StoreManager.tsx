import React, { useState } from 'react';
import { UnifiedOverlayLayout, TabType } from '../components/UnifiedOverlayLayout';
import { ConnectView } from '../components/ConnectView';
import { AlertTriangle, FileCheck, XCircle, BarChart2, Filter, User, Users, Target } from 'lucide-react';

interface Screen3Props {
  initialRole?: 'D2C' | 'Dealership';
  onGoHome?: () => void;
}

export function Screen3StoreManager({ initialRole = 'D2C', onGoHome }: Screen3Props) {
  const [role, setRole] = useState<'D2C' | 'Dealership'>(initialRole);
  const [activeTab, setActiveTab] = useState<TabType>('my_actions');

  const userName = role === 'D2C' ? 'Oliver Vance' : 'Robert Sterling';

  // --- Content Components ---

  const RoleSwitcher = () => (
    <div className="flex bg-neutral-100 p-0.5 rounded-lg">
      <button
        onClick={() => setRole('D2C')}
        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
          role === 'D2C' ? 'bg-white text-black shadow-sm' : 'text-neutral-400 hover:text-neutral-600'
        }`}
      >
        D2C
      </button>
      <button
        onClick={() => setRole('Dealership')}
        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
          role === 'Dealership' ? 'bg-white text-black shadow-sm' : 'text-neutral-400 hover:text-neutral-600'
        }`}
      >
        Dealer
      </button>
    </div>
  );

  const AvatarPanel = () => (
    <div className="flex items-center gap-3 bg-white p-1 sm:pl-4 sm:pr-2 sm:py-2 rounded-full shadow-sm border border-neutral-100 cursor-pointer hover:shadow-md transition-all">
      <div className="text-right hidden sm:block">
        <div className="text-xs font-bold text-neutral-900">{userName}</div>
        <div className="text-[10px] text-neutral-500 uppercase tracking-wide">
          {role === 'D2C' ? 'Store Manager' : 'Dealer Principal'}
        </div>
      </div>
      <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-neutral-900 text-white flex items-center justify-center border-2 border-white shadow-sm relative">
        <User size={18} />
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'my_actions':
        return (
          <div className="space-y-4 max-w-3xl mx-auto">
            <h3 className="text-xl font-bold mb-4">My Actions</h3>
            {role === 'Dealership' && (
              <div className="flex items-center gap-2 text-sm font-medium text-blue-600 bg-blue-50 px-3 py-2 rounded-lg w-fit mb-4">
                <Filter size={16} />
                Brand Filter Active
              </div>
            )}
            <ActionCard icon={<AlertTriangle size={24} className="text-amber-500" />} label="Escalation Queue" count={3} description="High priority issues requiring attention" urgent />
            <ActionCard icon={<FileCheck size={24} className="text-blue-500" />} label="Approval Requests" count={8} description="Pending approvals for deals and inventory" />
            <ActionCard icon={<BarChart2 size={24} className="text-purple-500" />} label="Lost Analysis" count={0} description="Review lost sales and opportunities" />
            <ActionCard icon={<XCircle size={24} className="text-red-500" />} label="Cancelled Orders" count={1} description="Recent order cancellations" />
          </div>
        );
      case 'profile':
        return (
          <div className="space-y-6 max-w-3xl mx-auto">
            <h3 className="text-xl font-bold mb-4">Profile & Metrics</h3>
            
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-neutral-100">
               <div className="text-xs font-bold uppercase text-neutral-400 mb-4">Pipeline Health</div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-neutral-600">Team Funnel</span>
                    <span className="font-bold text-neutral-900">Healthy</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-neutral-600">Deep-dive</span>
                    <span className="text-xs text-blue-600 cursor-pointer hover:underline">View Report</span>
                  </div>
                  
                  <div className="mt-4 pt-3 border-t border-neutral-100">
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-xs text-neutral-500">Store Target</span>
                        <span className="text-xs font-bold">82%</span>
                    </div>
                    <div className="w-full bg-neutral-100 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-neon-lime h-full rounded-full" style={{ width: '82%' }}></div>
                    </div>
                  </div>
                </div>
            </div>

            {/* Team Performance */}
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-neutral-100">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-neutral-100 rounded-xl"><Users size={20} /></div>
                  <h3 className="font-bold">Team Performance</h3>
                </div>
                <button className="text-xs font-medium text-neutral-500 hover:text-black">View All</button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <TeamCard name="Sam Parker" role="Advisor" sales={14} target={20} />
                <TeamCard name="Maria Garcia" role="Advisor" sales={18} target={20} highlight />
                <TeamCard name="James Wilson" role="Advisor" sales={9} target={20} alert />
              </div>
            </div>

             {/* Inventory Overview */}
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-neutral-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-neutral-100 rounded-xl"><Target size={20} /></div>
                <h3 className="font-bold">Inventory</h3>
              </div>
              <div className="space-y-4">
                <MetricRow label="Total Stock" value="142" />
                <MetricRow label="In Transit" value="28" />
                <MetricRow label="Stock Transfer" value="4 Pending" />
                <MetricRow label="Days Supply" value="45" />
              </div>
            </div>

          </div>
        );
      case 'Connect':
        return <ConnectView role={role} userName={userName} userTitle={role === 'D2C' ? 'Store Manager' : 'Dealer Principal'} />;
      case 'Vehicles':
      case 'Fulfillment':
        return (
          <div className="flex flex-col items-center justify-center h-full text-neutral-400 space-y-4">
             <div className="w-20 h-20 rounded-full bg-neutral-100 flex items-center justify-center">
               <Target size={32} />
             </div>
             <div className="text-center">
               <h3 className="text-lg font-bold text-neutral-900">{activeTab}</h3>
               <p className="font-medium">Workflow Dashboard</p>
             </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <UnifiedOverlayLayout
      title="Store Management"
      roleSwitcher={<RoleSwitcher />}
      avatarPanel={<AvatarPanel />}
      workflowOptions={['Connect', 'Vehicles', 'Fulfillment']}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onGoHome={onGoHome}
    >
      {renderContent()}
    </UnifiedOverlayLayout>
  );
}

function ActionCard({ icon, label, count, description, urgent }: { icon: React.ReactNode, label: string, count: number, description: string, urgent?: boolean }) {
  return (
    <div className={`p-6 rounded-2xl shadow-sm border flex items-center justify-between group cursor-pointer hover:shadow-md transition-all ${urgent ? 'bg-red-50 border-red-100' : 'bg-white border-neutral-100'}`}>
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${urgent ? 'bg-white text-red-500' : 'bg-neutral-50 group-hover:bg-neutral-100'}`}>
          {icon}
        </div>
        <div>
          <h4 className={`font-bold ${urgent ? 'text-red-900' : 'text-neutral-900'}`}>{label}</h4>
          <p className={`text-sm ${urgent ? 'text-red-600' : 'text-neutral-500'}`}>{description}</p>
        </div>
      </div>
      <span className={`text-sm font-bold px-3 py-1 rounded-full ${urgent ? 'bg-red-200 text-red-800' : 'bg-neutral-900 text-white'}`}>
        {count}
      </span>
    </div>
  );
}

function MetricRow({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex justify-between items-center p-2 hover:bg-neutral-50 rounded-lg transition-colors">
      <span className="text-sm text-neutral-500">{label}</span>
      <span className="font-bold text-neutral-900">{value}</span>
    </div>
  );
}

function TeamCard({ name, role, sales, target, highlight, alert }: { name: string, role: string, sales: number, target: number, highlight?: boolean, alert?: boolean }) {
    const percentage = Math.round((sales / target) * 100);
    return (
        <div className={`p-4 rounded-2xl border ${highlight ? 'bg-neon-lime/10 border-neon-lime/50' : alert ? 'bg-red-50 border-red-100' : 'bg-neutral-50 border-neutral-100'}`}>
            <div className="flex justify-between items-start mb-2">
                <div>
                    <div className="font-bold text-sm">{name}</div>
                    <div className="text-xs text-neutral-500">{role}</div>
                </div>
                <div className={`text-xs font-bold ${highlight ? 'text-green-700' : alert ? 'text-red-600' : 'text-neutral-700'}`}>
                    {percentage}%
                </div>
            </div>
            <div className="w-full bg-white h-1.5 rounded-full overflow-hidden">
                <div 
                    className={`h-full rounded-full ${highlight ? 'bg-green-500' : alert ? 'bg-red-500' : 'bg-black'}`} 
                    style={{ width: `${percentage}%` }}
                ></div>
            </div>
        </div>
    )
}

