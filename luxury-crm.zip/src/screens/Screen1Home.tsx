import React, { useState } from 'react';
import { User, Briefcase, Building, BarChart, ArrowUpRight, Activity } from 'lucide-react';

interface Screen1Props {
  onNavigate?: (screenId: number, role?: 'D2C' | 'Dealership') => void;
}

export function Screen1Home({ onNavigate }: Screen1Props) {
  const [activeMobileTab, setActiveMobileTab] = useState<'d2c' | 'dealer' | 'oem'>('d2c');

  const cards = [
    {
      id: 'd2c',
      label: 'Direct to Consumer',
      title: 'D2C Retail',
      description: 'Manage direct sales, customer experiences, and store operations.',
      color: 'rose',
      roles: [
        { title: 'Client Advisor', icon: <User size={18} />, action: () => onNavigate?.(2, 'D2C') },
        { title: 'Store Manager', icon: <Briefcase size={18} />, action: () => onNavigate?.(3, 'D2C') }
      ]
    },
    {
      id: 'dealer',
      label: 'Partner Network',
      title: 'Dealerships',
      description: 'Franchise operations, inventory management, and brand coordination.',
      color: 'blue',
      roles: [
        { title: 'Sales Consultant', icon: <User size={18} />, action: () => onNavigate?.(2, 'Dealership') },
        { title: 'Dealer Principal', icon: <Building size={18} />, action: () => onNavigate?.(3, 'Dealership') }
      ]
    },
    {
      id: 'oem',
      label: 'Corporate',
      title: 'OEM HQ',
      description: 'Global strategy, regional operations, and executive oversight.',
      color: 'neutral',
      roles: [
        { title: 'Regional Manager', icon: <BarChart size={18} />, action: () => onNavigate?.(4) },
        { title: 'Executive Leadership', icon: <Briefcase size={18} />, action: () => onNavigate?.(5) }
      ]
    }
  ];

  return (
    <div className="min-h-screen p-6 md:p-12 lg:p-16 max-w-7xl mx-auto flex flex-col">
      
      {/* Header with Logo */}
      <div className="flex items-center gap-3 mb-8 md:mb-12">
        <div className="bg-white p-2 rounded-xl shadow-sm border border-neutral-100">
          <div className="w-6 h-6 bg-black rounded-lg flex items-center justify-center text-white font-serif font-bold text-xs">
            L
          </div>
        </div>
        <span className="font-bold text-lg tracking-tight">Luxury</span>
      </div>

      {/* Hero Section */}
      <div className="flex flex-col xl:flex-row items-start xl:items-end justify-between gap-8 mb-12">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-white px-3 py-1 rounded-full shadow-sm mb-6 border border-neutral-100">
            <span className="w-2 h-2 rounded-full bg-neon-lime"></span>
            <span className="text-xs font-bold uppercase tracking-wide text-neutral-600">Enterprise Ecosystem</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-neutral-900 tracking-tight leading-[1.1] mb-6">
            Select Your Workspace
          </h1>
          <p className="text-neutral-500 text-lg md:text-xl leading-relaxed">
            Access tailored workflows for D2C Retail, Franchised Dealerships, and OEM Headquarters.
          </p>
        </div>
        
        {/* Stats - Compact on Mobile, Expanded on Desktop */}
        <div className="flex gap-4 w-full xl:w-auto">
          <div className="bg-white px-5 py-4 rounded-2xl shadow-sm border border-neutral-100 flex-1 xl:w-40 flex flex-col justify-center">
            <div className="text-xs text-neutral-400 font-bold uppercase tracking-wider mb-1">Active Users</div>
            <div className="text-2xl font-bold text-neutral-900">12.4k</div>
          </div>
          <div className="bg-black text-white px-5 py-4 rounded-2xl shadow-lg flex-1 xl:w-40 flex flex-col justify-center group cursor-pointer hover:scale-105 transition-transform">
            <div className="text-xs text-neutral-400 font-bold uppercase tracking-wider mb-1">System Status</div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-neon-lime rounded-full animate-pulse"></span>
              <span className="font-bold text-lg">Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Tab Switcher */}
      <div className="md:hidden flex p-1 bg-neutral-100 rounded-xl mb-6">
        {cards.map((card) => (
          <button
            key={card.id}
            onClick={() => setActiveMobileTab(card.id as any)}
            className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${
              activeMobileTab === card.id
                ? 'bg-white text-black shadow-sm'
                : 'text-neutral-400 hover:text-neutral-600'
            }`}
          >
            {card.title.split(' ')[0]}
          </button>
        ))}
      </div>

      {/* Cards Layout */}
      <div className="flex-1">
        {/* Desktop Grid */}
        <div className="hidden md:grid md:grid-cols-3 gap-6 h-full">
          {cards.map((card) => (
            <WorkspaceCard key={card.id} card={card} />
          ))}
        </div>

        {/* Mobile View - Single Active Card */}
        <div className="md:hidden h-full">
          {cards.map((card) => (
            activeMobileTab === card.id && (
              <WorkspaceCard key={card.id} card={card} />
            )
          ))}
        </div>
      </div>
    </div>
  );
}

function WorkspaceCard({ card }: { card: any; key?: any }) {
  const colors: Record<string, string> = {
    rose: 'bg-rose-50 text-rose-600',
    blue: 'bg-blue-50 text-blue-600',
    neutral: 'bg-neutral-100 text-neutral-600'
  };

  const bgColors: Record<string, string> = {
    rose: 'bg-rose-50',
    blue: 'bg-blue-50',
    neutral: 'bg-neutral-100'
  };

  return (
    <div className="bg-white rounded-[2rem] p-6 md:p-8 shadow-sm border border-neutral-100 relative overflow-hidden group hover:shadow-xl hover:border-neutral-200 transition-all duration-300 flex flex-col h-full">
      <div className="absolute top-6 right-6 md:top-8 md:right-8 z-20">
        <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-neutral-50 flex items-center justify-center group-hover:bg-black group-hover:text-white transition-colors duration-300">
          <ArrowUpRight size={20} className="md:w-6 md:h-6" />
        </div>
      </div>
      
      <div className="relative z-10 flex-1 flex flex-col">
        <div className={`inline-block px-3 py-1 md:px-4 md:py-1.5 rounded-full font-bold text-[10px] md:text-xs mb-6 w-fit ${colors[card.color]}`}>
          {card.label}
        </div>
        <h2 className="text-2xl md:text-3xl font-bold mb-3 text-neutral-900">{card.title}</h2>
        <p className="text-neutral-500 mb-8 flex-1 text-sm md:text-base leading-relaxed">
          {card.description}
        </p>

        <div className="space-y-3 mt-auto">
          {card.roles.map((role: any, idx: number) => (
            <RolePill 
              key={idx}
              title={role.title} 
              icon={role.icon} 
              onClick={role.action}
            />
          ))}
        </div>
      </div>
      
      <div className={`absolute -bottom-12 -right-12 w-48 h-48 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none ${bgColors[card.color]}`}></div>
    </div>
  );
}

function RolePill({ title, icon, onClick }: { title: string; icon: React.ReactNode; onClick?: () => void; key?: any }) {
  return (
    <button 
      onClick={onClick}
      className="flex items-center gap-3 p-3 md:p-4 rounded-2xl bg-neutral-50 hover:bg-black hover:text-white transition-all duration-200 group/pill w-full text-left border border-transparent hover:border-black/10"
    >
      <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-white text-black flex items-center justify-center shadow-sm group-hover/pill:bg-white/20 group-hover/pill:text-white transition-colors">
        {icon}
      </div>
      <span className="font-bold text-sm md:text-base">{title}</span>
    </button>
  );
}
