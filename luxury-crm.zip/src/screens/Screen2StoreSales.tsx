import React, { useState, useEffect } from 'react';
import { UnifiedOverlayLayout, TabType } from '../components/UnifiedOverlayLayout';
import { ConnectView } from '../components/ConnectView';
import { SalesDashboard } from '../components/SalesDashboard';
import { CheckCircle2, AlertCircle, Calendar, User, TrendingUp, Filter, BookOpen, ChevronRight, Search, X, ArrowLeft, Phone, Mail, MessageSquare, Clock, Check, AlertTriangle, ArrowRightLeft, FileText, Car } from 'lucide-react';

interface Screen2Props {
  initialRole?: 'D2C' | 'Dealership';
  onGoHome?: () => void;
}

// --- Types for Profile Page ---
type Stage = 'new_leads' | 'qualified' | 'converted' | 'closing';
type ActivityTag = 'engaged' | 'configured' | 'test_drive' | 'quote' | 'finance' | 'trade_in' | 'order' | 'handover';
type Result = 'new' | 'in_process' | 'transferred' | 'won' | 'lost';
type LeadSource = 'Walk-in' | 'Online' | 'Event' | 'Referral' | 'Outbound';

interface TimelineEntry {
  id: string;
  date: string;
  type: 'status_change' | 'note' | 'activity' | 'system';
  content: string;
  author: string;
}

interface Customer {
  id: string;
  name: string;
  stage: Stage;
  tags: ActivityTag[];
  result: Result;
  source: LeadSource;
  email: string;
  phone: string;
  lastContact: string;
  notes: string;
  vehicleInterest: string;
  
  // Detailed Profile Fields (GDPR Masked)
  gender?: 'Male' | 'Female' | 'Non-binary' | 'Prefer not to say';
  language?: string;
  address?: string;
  
  driversLicense?: string;
  ssnTaxId?: string;
  
  preferredContactMethod?: 'SMS' | 'Email' | 'Phone';
  
  // Module Data (Complex & Realistic)
  configurations?: { 
    id: string; 
    model: string; 
    trim?: string;
    paint?: string;
    wheels?: string;
    price: string; 
    date: string;
  }[];
  
  testDrives?: { 
    id: string; 
    vin: string; 
    model: string; 
    date: string; 
    status: 'Scheduled' | 'Completed' | 'Cancelled';
    feedback?: string;
  }[];
  
  quotes?: { 
    id: string; 
    configId: string; 
    financeOption?: string;
    monthlyPayment?: string;
    amount: string; 
    status: 'Draft' | 'Sent' | 'Expired' | 'Accepted';
    date: string;
  }[];
  
  finance?: { 
    id: string;
    status: 'Pending' | 'Approved' | 'Rejected' | 'More Info Needed'; 
    provider: string; 
    amount: string;
    term?: string;
    apr?: string;
  }[];
  
  tradeIn?: { 
    id: string;
    vehicle: string; 
    vin: string; 
    value: string; 
    status: 'Appraised' | 'Pending' | 'Accepted';
    condition?: string;
  }[];
  
  orders?: { 
    id: string; 
    configId: string; 
    quoteId?: string;
    rnNumber?: string;
    status: 'Placed' | 'Confirmed' | 'In Production' | 'Delivered';
    date: string;
  }[];
  
  handover?: { 
    date: string; 
    location: string;
    specialist: string;
    status: 'Scheduled' | 'Completed';
    checklist?: string[];
  };

  // Timeline
  timeline: TimelineEntry[];

  // Extra fields for logic
  transferPath?: string;
  orderId?: string;
  vin?: string;
  lostReason?: string;
}

// --- Constants ---
const ALL_TAGS: ActivityTag[] = ['engaged', 'configured', 'test_drive', 'quote', 'finance', 'trade_in', 'order', 'handover'];
const LEAD_SOURCES: LeadSource[] = ['Walk-in', 'Online', 'Event', 'Referral', 'Outbound'];

// --- Mock Data ---
const MOCK_CUSTOMERS: Customer[] = [
  { 
    id: '1', name: 'Alice Johnson', stage: 'new_leads', tags: [], result: 'new', source: 'Online',
    email: 'a***@example.com', phone: '***-***-0101', lastContact: '2 hours ago', notes: 'Inquired about Pulsar SUV pricing.', vehicleInterest: 'Pulsar SUV',
    timeline: [
      { id: 't1', date: '2 hours ago', type: 'activity', content: 'Customer created via Web Inquiry', author: 'System' }
    ]
  },
  { 
    id: '2', name: 'Bob Smith', stage: 'qualified', tags: ['engaged', 'test_drive'], result: 'in_process', source: 'Walk-in',
    email: 'b***@example.com', phone: '***-***-0102', lastContact: '1 day ago', notes: 'Loved the test drive, discussing financing.', vehicleInterest: 'Nebula GT',
    driversLicense: '*******5678', preferredContactMethod: 'Phone',
    testDrives: [{ id: 'td1', vin: '5YJ3...8888', model: 'Apex GT Performance', date: 'Yesterday', status: 'Completed', feedback: 'Loved the acceleration.' }],
    timeline: [
      { id: 't1', date: '1 day ago', type: 'activity', content: 'Test Drive Completed', author: 'Sam Parker' },
      { id: 't2', date: '2 days ago', type: 'note', content: 'Scheduled test drive for Apex GT', author: 'Sam Parker' }
    ]
  },
  { 
    id: '3', name: 'Charlie Davis', stage: 'closing', tags: ['engaged', 'configured', 'quote', 'finance', 'trade_in', 'order'], result: 'won', source: 'Referral',
    email: 'c***@example.com', phone: '***-***-0103', lastContact: '3 days ago', notes: 'Complex deal with trade-in and financing. Delivery scheduled.', vehicleInterest: 'Spectra Sedan', orderId: 'ORD-2024-001', vin: '5YJSA1E2...',
    address: '123 Maple Ave, Austin, TX',
    driversLicense: '*******9012',
    ssnTaxId: '***-**-1234',
    configurations: [
      { id: 'c1', model: 'Spectra Sedan Plaid', trim: 'Plaid', paint: 'Ultra Red', wheels: '21" Arachnid', price: '$89,990', date: '5 days ago' },
      { id: 'c2', model: 'Spectra Sedan', trim: 'Long Range', paint: 'Stealth Grey', wheels: '19" Tempest', price: '$74,990', date: '5 days ago' }
    ],
    testDrives: [
      { id: 'td1', vin: '5YJ...9999', model: 'Spectra Sedan Plaid', date: '4 days ago', status: 'Completed', feedback: 'Insane mode is amazing.' }
    ],
    quotes: [
      { id: 'q1', configId: 'c1', amount: '$92,500', monthlyPayment: '$1,250/mo', status: 'Sent', date: '4 days ago' },
      { id: 'q2', configId: 'c2', amount: '$78,000', monthlyPayment: '$980/mo', status: 'Draft', date: '4 days ago' }
    ],
    finance: [
      { id: 'f1', provider: 'Luxury Finance', amount: '$60,000', term: '72 months', apr: '6.49%', status: 'Approved' }
    ],
    tradeIn: [
      { id: 'tr1', vehicle: '2020 BMW M3', vin: 'WBS...5555', value: '$45,000', status: 'Appraised', condition: 'Excellent' }
    ],
    orders: [
      { id: 'o1', configId: 'c1', quoteId: 'q1', rnNumber: 'RN112233445', status: 'Confirmed', date: '3 days ago' }
    ],
    handover: {
      date: '2023-11-20', location: 'Austin South Delivery Center', specialist: 'Sarah Connor', status: 'Scheduled', checklist: ['Registration', 'App Setup']
    },
    timeline: [
      { id: 't1', date: '3 days ago', type: 'status_change', content: 'Order Placed (RN112233445)', author: 'System' },
      { id: 't2', date: '4 days ago', type: 'activity', content: 'Finance Approved', author: 'System' },
      { id: 't3', date: '4 days ago', type: 'activity', content: 'Trade-In Appraised: 2020 BMW M3', author: 'Sam Parker' },
      { id: 't4', date: '4 days ago', type: 'activity', content: 'Quote #q1 Sent', author: 'Sam Parker' }
    ]
  },
  { 
    id: '4', name: 'Diana Evans', stage: 'closing', tags: ['engaged', 'quote'], result: 'lost', source: 'Event',
    email: 'd***@example.com', phone: '***-***-0104', lastContact: '1 week ago', notes: 'Competitor offered better trade-in value.', vehicleInterest: 'Horizon EV', lostReason: 'Price Competitiveness',
    quotes: [{ id: 'q1', configId: 'c1', amount: '$82,000', status: 'Sent', date: '1 week ago' }],
    timeline: [
      { id: 't1', date: '1 week ago', type: 'status_change', content: 'Marked as Lost: Price Competitiveness', author: 'Sam Parker' }
    ]
  },
  { 
    id: '5', name: 'Evan Wright', stage: 'closing', tags: ['engaged'], result: 'transferred', source: 'Online',
    email: 'e***@example.com', phone: '***-***-0105', lastContact: '5 hours ago', notes: 'Moved to another region.', vehicleInterest: 'Apex GT', transferPath: 'Store A -> Store B',
    timeline: [
      { id: 't1', date: '5 hours ago', type: 'status_change', content: 'Transferred to Store B', author: 'Sam Parker' }
    ]
  },
  { 
    id: '6', name: 'Fiona Hill', stage: 'converted', tags: ['engaged', 'configured'], result: 'in_process', source: 'Walk-in',
    email: 'f***@example.com', phone: '***-***-0106', lastContact: '2 days ago', notes: 'Asking about color options.', vehicleInterest: 'Summit SUV',
    configurations: [{ id: 'c1', model: 'Summit SUV Long Range', price: '$48,990', date: '2 days ago' }],
    timeline: [
      { id: 't1', date: '2 days ago', type: 'activity', content: 'Configuration Saved', author: 'Sam Parker' }
    ]
  },
  { 
    id: '7', name: 'George Baker', stage: 'converted', tags: ['engaged', 'finance'], result: 'in_process', source: 'Referral',
    email: 'g***@example.com', phone: '***-***-0107', lastContact: '4 hours ago', notes: 'Waiting for credit approval.', vehicleInterest: 'Titan Truck',
    finance: [{ id: 'f1', status: 'Pending', provider: 'Luxury Finance', amount: '$60,000' }],
    timeline: [
      { id: 't1', date: '4 hours ago', type: 'activity', content: 'Finance Application Submitted', author: 'System' }
    ]
  },
  { id: '8', name: 'Hannah Lee', stage: 'new_leads', tags: [], result: 'new', source: 'Walk-in', email: 'h***@example.com', phone: '***-***-0108', lastContact: '10 mins ago', notes: 'Walk-in customer, interested in test drive.', vehicleInterest: 'Apex GT', timeline: [] },
  { id: '9', name: 'Ian Clark', stage: 'qualified', tags: ['engaged'], result: 'in_process', source: 'Online', email: 'i***@example.com', phone: '***-***-0109', lastContact: '3 days ago', notes: 'Sent brochure, waiting for reply.', vehicleInterest: 'Horizon EV', timeline: [] },
  { id: '10', name: 'Jack Wilson', stage: 'converted', tags: ['engaged', 'test_drive', 'trade_in'], result: 'in_process', source: 'Event', email: 'j***@example.com', phone: '***-***-0110', lastContact: '1 day ago', notes: 'Evaluating trade-in offer.', vehicleInterest: 'Summit SUV', timeline: [] },
  { id: '11', name: 'Karen White', stage: 'closing', tags: ['engaged', 'configured', 'quote', 'handover'], result: 'won', source: 'Referral', email: 'k***@example.com', phone: '***-***-0111', lastContact: '1 hour ago', notes: 'Vehicle delivered successfully.', vehicleInterest: 'Apex GT', orderId: 'ORD-2024-002', vin: '5YJSA1E3...', timeline: [] },
  { id: '12', name: 'Leo Martin', stage: 'closing', tags: ['engaged', 'test_drive'], result: 'lost', source: 'Outbound', email: 'l***@example.com', phone: '***-***-0112', lastContact: '2 weeks ago', notes: 'Decided to wait for next year model.', vehicleInterest: 'Titan Truck', lostReason: 'Timing', timeline: [] },
  { id: '13', name: 'Mia Scott', stage: 'qualified', tags: ['engaged', 'configured'], result: 'in_process', source: 'Online', email: 'm***@example.com', phone: '***-***-0113', lastContact: '5 days ago', notes: 'Configured online, needs to schedule test drive.', vehicleInterest: 'Spectra Sedan', timeline: [] },
  { id: '14', name: 'Noah King', stage: 'new_leads', tags: [], result: 'new', source: 'Online', email: 'n***@example.com', phone: '***-***-0114', lastContact: '1 day ago', notes: 'Web inquiry about leasing options.', vehicleInterest: 'Summit SUV', timeline: [] },
  { id: '15', name: 'Olivia Green', stage: 'closing', tags: ['engaged'], result: 'transferred', source: 'Walk-in', email: 'o***@example.com', phone: '***-***-0115', lastContact: '2 days ago', notes: 'Customer moved to different state.', vehicleInterest: 'Apex GT', transferPath: 'Store B -> Store C', timeline: [] },
];

export function Screen2StoreSales({ initialRole = 'D2C', onGoHome }: Screen2Props) {
  const [role, setRole] = useState<'D2C' | 'Dealership'>(initialRole);
  const [activeTab, setActiveTab] = useState<TabType>('my_actions');
  
  const userName = role === 'D2C' ? 'Jordan Miller' : 'Sam Parker';

  // --- Profile Page State ---
  const [activeStage, setActiveStage] = useState<Stage | 'all'>('all');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedTags, setSelectedTags] = useState<ActivityTag[]>([]);
  const [selectedResults, setSelectedResults] = useState<Result[]>([]);
  const [selectedSources, setSelectedSources] = useState<LeadSource[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Local state for editing a customer in detail view
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [showLostModal, setShowLostModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [actionReason, setActionReason] = useState('');
  const [transferTarget, setTransferTarget] = useState('');

  useEffect(() => {
    if (selectedCustomer) {
      setEditingCustomer({ ...selectedCustomer });
    } else {
      setEditingCustomer(null);
    }
  }, [selectedCustomer]);

  // --- Logic Engine ---
  const updateCustomerLogic = (customer: Customer, newTags: ActivityTag[], manualResult?: 'lost' | 'transferred', reason?: string, target?: string): Customer => {
    let tags = [...newTags];
    let result: Result = customer.result;
    let stage: Stage = customer.stage;
    let extraFields = {};
    let newTimelineEntry: TimelineEntry | null = null;

    // 1. Determine Result
    if (manualResult) {
      result = manualResult;
      if (manualResult === 'lost') {
        extraFields = { lostReason: reason || 'Other' };
        newTimelineEntry = { id: Date.now().toString(), date: 'Just now', type: 'status_change', content: `Marked as Lost: ${reason}`, author: 'Sam Parker' };
      }
      if (manualResult === 'transferred') {
        extraFields = { transferPath: target || 'Pending Transfer...' };
        newTimelineEntry = { id: Date.now().toString(), date: 'Just now', type: 'status_change', content: `Transferred to ${target}`, author: 'Sam Parker' };
      }
    } else {
      // Auto-calculate result based on tags
      if (tags.includes('order') || tags.includes('handover')) {
        result = 'won';
        if (!customer.orderId) extraFields = { ...extraFields, orderId: 'ORD-NEW-001', vin: 'PENDING-VIN' };
      } else if (tags.includes('engaged')) {
        result = 'in_process';
      } else {
        result = 'new';
      }
    }

    // 2. Determine Stage
    if (result === 'transferred' || result === 'lost' || result === 'won') {
      stage = 'closing';
    } else {
      // In Process or New
      const convertedTags: ActivityTag[] = ['configured', 'test_drive', 'quote', 'finance', 'trade_in'];
      if (tags.some(t => convertedTags.includes(t))) {
        stage = 'converted';
      } else if (tags.includes('engaged')) {
        stage = 'qualified';
      } else {
        stage = 'new_leads';
      }
    }

    const updatedCustomer = { ...customer, tags, result, stage, ...extraFields };
    if (newTimelineEntry) {
      updatedCustomer.timeline = [newTimelineEntry, ...(updatedCustomer.timeline || [])];
    }
    return updatedCustomer;
  };

  const handleTagToggle = (tag: ActivityTag) => {
    if (!editingCustomer) return;
    const isActive = editingCustomer.tags.includes(tag);
    const newTags = isActive 
      ? editingCustomer.tags.filter(t => t !== tag) 
      : [...editingCustomer.tags, tag];
    
    const updated = updateCustomerLogic(editingCustomer, newTags);
    setEditingCustomer(updated);
  };

  const handleManualActionSubmit = () => {
    if (!editingCustomer) return;
    if (showLostModal) {
      const updated = updateCustomerLogic(editingCustomer, editingCustomer.tags, 'lost', actionReason);
      setEditingCustomer(updated);
      setShowLostModal(false);
    } else if (showTransferModal) {
      const updated = updateCustomerLogic(editingCustomer, editingCustomer.tags, 'transferred', actionReason, transferTarget);
      setEditingCustomer(updated);
      setShowTransferModal(false);
    }
    setActionReason('');
    setTransferTarget('');
  };

  // --- Content Components ---

  const RoleSwitcher = () => (
    <div className="flex bg-neutral-100 p-0.5 rounded-lg">
      <button
        onClick={() => setRole('D2C')}
        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
          role === 'D2C' ? 'bg-white text-black shadow-sm' : 'text-neutral-400 hover:text-neutral-600'
        }`}
      >
        D2C
      </button>
      <button
        onClick={() => setRole('Dealership')}
        className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${
          role === 'Dealership' ? 'bg-white text-black shadow-sm' : 'text-neutral-400 hover:text-neutral-600'
        }`}
      >
        Dealer
      </button>
    </div>
  );

  const AvatarPanel = () => (
    <div className="flex items-center gap-3 bg-white p-1 sm:pl-4 sm:pr-2 sm:py-2 rounded-full shadow-sm border border-neutral-100 cursor-pointer hover:shadow-md transition-all">
      <div className="text-right hidden sm:block">
        <div className="text-xs font-bold text-neutral-900">{userName}</div>
        <div className="text-[10px] text-neutral-500 uppercase tracking-wide">
          {role === 'D2C' ? 'Client Advisor' : 'Sales Consultant'}
        </div>
      </div>
      <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-neutral-900 text-white flex items-center justify-center border-2 border-white shadow-sm relative">
        <User size={18} />
      </div>
    </div>
  );

  // --- Profile Page Logic ---

  const filteredCustomers = MOCK_CUSTOMERS.filter(customer => {
    // Search Filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (!customer.name.toLowerCase().includes(query) && !customer.email.toLowerCase().includes(query)) {
        return false;
      }
    }

    // Stage Filter
    if (activeStage !== 'all' && customer.stage !== activeStage) return false;

    // Tag Filter (OR logic within tags)
    if (selectedTags.length > 0 && !customer.tags.some(tag => selectedTags.includes(tag))) return false;

    // Result Filter (OR logic within results)
    if (selectedResults.length > 0 && !selectedResults.includes(customer.result)) return false;

    // Source Filter (OR logic within sources)
    if (selectedSources.length > 0 && !selectedSources.includes(customer.source)) return false;

    return true;
  });

  const toggleFilterTag = (tag: ActivityTag) => {
    setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]);
  };

  const toggleFilterResult = (result: Result) => {
    setSelectedResults(prev => prev.includes(result) ? prev.filter(r => r !== result) : [...prev, result]);
  };

  const toggleFilterSource = (source: LeadSource) => {
    setSelectedSources(prev => prev.includes(source) ? prev.filter(s => s !== source) : [...prev, source]);
  };

  const renderProfileContent = () => {
    if (editingCustomer) {
      return (
        <div className="max-w-7xl mx-auto animate-in slide-in-from-right-4 fade-in duration-300">
          <button 
            onClick={() => setSelectedCustomer(null)}
            className="flex items-center gap-2 text-neutral-500 hover:text-black mb-6 transition-colors"
          >
            <ArrowLeft size={18} />
            <span className="font-bold text-sm">Back to List</span>
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Modules */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Header Card */}
              <div className="bg-white rounded-3xl shadow-sm border border-neutral-100 p-8">
                <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-6">
                  <div>
                    <h2 className="text-3xl font-bold text-neutral-900 mb-2">{editingCustomer.name}</h2>
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="bg-black text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                        {editingCustomer.stage.replace('_', ' ')}
                      </span>
                      <span className={`text-xs font-bold px-3 py-1 rounded-full border uppercase tracking-wide ${
                        editingCustomer.result === 'won' ? 'bg-green-50 text-green-700 border-green-200' :
                        editingCustomer.result === 'lost' ? 'bg-red-50 text-red-700 border-red-200' :
                        editingCustomer.result === 'transferred' ? 'bg-orange-50 text-orange-700 border-orange-200' :
                        'bg-white text-neutral-600 border-neutral-200'
                      }`}>
                        {editingCustomer.result.replace('_', ' ')}
                      </span>
                      {/* Lead Source Badge */}
                      <span className="text-xs font-bold px-3 py-1 rounded-full border border-blue-200 bg-blue-50 text-blue-700 uppercase tracking-wide">
                        {editingCustomer.source}
                      </span>
                    </div>
                  </div>
                  
                  {/* Manual Actions */}
                  <div className="flex gap-2">
                     {editingCustomer.result !== 'lost' && editingCustomer.result !== 'won' && (
                       <button onClick={() => setShowLostModal(true)} className="px-4 py-2 bg-white border border-red-200 text-red-600 rounded-xl text-xs font-bold hover:bg-red-50 transition-colors">
                         Mark Lost
                       </button>
                     )}
                     {editingCustomer.result !== 'transferred' && editingCustomer.result !== 'won' && (
                       <button onClick={() => setShowTransferModal(true)} className="px-4 py-2 bg-white border border-orange-200 text-orange-600 rounded-xl text-xs font-bold hover:bg-orange-50 transition-colors">
                         Transfer
                       </button>
                     )}
                  </div>
                </div>

                {/* Activity Tracker */}
                <div className="mb-8">
                  <h3 className="font-bold text-sm uppercase tracking-wide text-neutral-500 mb-3">Activity Tracker</h3>
                  <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
                    {ALL_TAGS.map(tag => {
                      const isActive = editingCustomer.tags.includes(tag);
                      return (
                        <button
                          key={tag}
                          onClick={() => handleTagToggle(tag)}
                          className={`flex flex-col items-center justify-center p-2 rounded-lg border transition-all ${
                            isActive 
                              ? 'bg-green-50 border-green-200 text-green-700' 
                              : 'bg-white border-neutral-100 text-neutral-300 hover:border-neutral-200'
                          }`}
                        >
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center mb-1 ${isActive ? 'bg-green-500 text-white' : 'bg-neutral-100 text-neutral-300'}`}>
                            {isActive ? <Check size={12} /> : <div className="w-2 h-2 rounded-full bg-neutral-300"></div>}
                          </div>
                          <span className="text-[9px] font-bold uppercase text-center leading-tight">{tag.replace('_', ' ')}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Module: Customer Info */}
              <ModuleCard title="Customer Profile" icon={<User size={20} />} isActive={true}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold uppercase text-neutral-400">Identity</h4>
                    <Field label="Full Name" value={editingCustomer.name} />
                    <Field label="Gender" value={editingCustomer.gender || '-'} />
                    <Field label="Language" value={editingCustomer.language || 'English'} />
                    <Field label="Source" value={editingCustomer.source} />
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold uppercase text-neutral-400">Contact</h4>
                    <Field label="Mobile" value={editingCustomer.phone} />
                    <Field label="Email" value={editingCustomer.email} />
                    <Field label="Address" value={editingCustomer.address || '-'} />
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold uppercase text-neutral-400">Identification</h4>
                    <Field label="Driver's License" value={editingCustomer.driversLicense ? '*******' + editingCustomer.driversLicense.slice(-4) : '-'} />
                    <Field label="SSN / Tax ID" value={editingCustomer.ssnTaxId ? '***-**-****' : '-'} />
                  </div>
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold uppercase text-neutral-400">Preference</h4>
                    <Field label="Interest Model" value={editingCustomer.vehicleInterest} />
                    <Field label="Preferred Contact" value={editingCustomer.preferredContactMethod || 'Any'} />
                  </div>
                </div>
              </ModuleCard>

              {/* Module: Configuration */}
              <ModuleCard title="Configuration" icon={<FileText size={20} />} isActive={editingCustomer.tags.includes('configured')}>
                 {editingCustomer.configurations?.map(config => (
                   <div key={config.id} className="bg-neutral-50 p-3 rounded-lg border border-neutral-100 mb-2">
                     <div className="flex justify-between items-start mb-1">
                       <div className="font-bold text-sm">{config.model} <span className="text-neutral-500 font-normal">{config.trim}</span></div>
                       <div className="font-mono font-bold">{config.price}</div>
                     </div>
                     <div className="text-xs text-neutral-500 flex flex-wrap gap-2">
                       <span>{config.paint}</span>
                       <span className="w-px h-3 bg-neutral-300"></span>
                       <span>{config.wheels}</span>
                       <span className="w-px h-3 bg-neutral-300"></span>
                       <span>{config.date}</span>
                     </div>
                   </div>
                 )) || <EmptyState text="No configurations saved" />}
              </ModuleCard>

              {/* Module: Test Drive */}
              <ModuleCard title="Test Drive" icon={<Car size={20} />} isActive={editingCustomer.tags.includes('test_drive')}>
                {editingCustomer.testDrives?.map(td => (
                   <div key={td.id} className="bg-neutral-50 p-3 rounded-lg border border-neutral-100 mb-2">
                     <div className="flex justify-between items-center mb-1">
                       <div className="font-bold text-sm">{td.model}</div>
                       <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md uppercase ${td.status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-neutral-200 text-neutral-600'}`}>{td.status}</span>
                     </div>
                     <div className="text-xs text-neutral-500 mb-1">VIN: {td.vin}</div>
                     {td.feedback && <div className="text-xs text-neutral-600 italic bg-white p-2 rounded border border-neutral-100">"{td.feedback}"</div>}
                   </div>
                 )) || <EmptyState text="No test drives scheduled" />}
              </ModuleCard>

              {/* Module: Quote */}
              <ModuleCard title="Quote" icon={<FileText size={20} />} isActive={editingCustomer.tags.includes('quote')}>
                 {editingCustomer.quotes?.map(q => (
                   <div key={q.id} className="bg-neutral-50 p-3 rounded-lg border border-neutral-100 mb-2">
                     <div className="flex justify-between items-start mb-1">
                       <div>
                         <div className="font-bold text-sm">Quote #{q.id}</div>
                         <div className="text-xs text-neutral-500">Config: {q.configId}</div>
                       </div>
                       <div className="text-right">
                          <div className="font-mono font-bold">{q.amount}</div>
                          <div className="text-xs text-neutral-500">{q.monthlyPayment}</div>
                       </div>
                     </div>
                     <div className="flex justify-between items-center mt-2">
                       <span className="text-xs text-neutral-500">{q.financeOption}</span>
                       <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${q.status === 'Sent' ? 'bg-blue-50 text-blue-700' : 'bg-neutral-200 text-neutral-600'}`}>{q.status}</span>
                     </div>
                   </div>
                 )) || <EmptyState text="No quotes generated" />}
              </ModuleCard>

               {/* Module: Finance */}
               <ModuleCard title="Finance" icon={<TrendingUp size={20} />} isActive={editingCustomer.tags.includes('finance')}>
                 {editingCustomer.finance?.map(f => (
                   <div key={f.id} className="bg-neutral-50 p-3 rounded-lg border border-neutral-100 mb-2">
                     <div className="flex justify-between mb-1">
                       <span className="text-sm font-bold">{f.provider}</span>
                       <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${f.status === 'Approved' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{f.status}</span>
                     </div>
                     <div className="text-xs text-neutral-500 flex justify-between">
                       <span>Amount: {f.amount}</span>
                       <span>{f.apr} APR / {f.term}</span>
                     </div>
                   </div>
                 )) || <EmptyState text="No finance application" />}
              </ModuleCard>

              {/* Module: Trade-In */}
              <ModuleCard title="Trade-In" icon={<ArrowRightLeft size={20} />} isActive={editingCustomer.tags.includes('trade_in')}>
                 {editingCustomer.tradeIn?.map(t => (
                   <div key={t.id} className="bg-neutral-50 p-3 rounded-lg border border-neutral-100 mb-2">
                     <div className="font-bold text-sm mb-1">{t.vehicle}</div>
                     <div className="flex justify-between items-center text-xs text-neutral-500 mb-1">
                       <span>VIN: {t.vin}</span>
                       <span className="font-mono font-bold text-neutral-900">{t.value}</span>
                     </div>
                     <div className="flex justify-between items-center">
                        <span className="text-[10px] bg-neutral-200 px-1.5 py-0.5 rounded text-neutral-600">{t.condition}</span>
                        <span className="text-[10px] font-bold uppercase text-blue-600">{t.status}</span>
                     </div>
                   </div>
                 )) || <EmptyState text="No trade-in vehicle" />}
              </ModuleCard>

              {/* Module: Order */}
              <ModuleCard title="Order" icon={<CheckCircle2 size={20} />} isActive={editingCustomer.tags.includes('order')}>
                 {editingCustomer.orders?.map(o => (
                   <div key={o.id} className="bg-neutral-50 p-3 rounded-lg border border-neutral-100 mb-2">
                     <div className="flex justify-between items-center mb-1">
                       <div className="font-bold text-sm">Order #{o.rnNumber || o.id}</div>
                       <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded-md uppercase">{o.status}</span>
                     </div>
                     <div className="text-xs text-neutral-500">Config: {o.configId} • Quote: {o.quoteId || '-'}</div>
                   </div>
                 )) || <EmptyState text="No active orders" />}
              </ModuleCard>

              {/* Module: Handover */}
              <ModuleCard title="Handover" icon={<Check size={20} />} isActive={editingCustomer.tags.includes('handover')}>
                {editingCustomer.handover ? (
                  <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-100">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-bold">{editingCustomer.handover.date}</span>
                      <span className="px-2 py-0.5 bg-green-100 text-green-800 text-[10px] font-bold rounded-md uppercase">{editingCustomer.handover.status}</span>
                    </div>
                    <div className="text-xs text-neutral-500 mb-2">{editingCustomer.handover.location}</div>
                    <div className="text-xs text-neutral-500 mb-2">Specialist: {editingCustomer.handover.specialist}</div>
                    {editingCustomer.handover.checklist && (
                      <div className="space-y-1 mt-2 border-t border-neutral-100 pt-2">
                        {editingCustomer.handover.checklist.map((item, i) => (
                          <div key={i} className="flex items-center gap-2 text-xs text-neutral-600">
                            <Check size={10} className="text-green-500" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : <EmptyState text="Handover not scheduled" />}
              </ModuleCard>

            </div>

            {/* Right Column: Timeline */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-3xl shadow-sm border border-neutral-100 p-6 sticky top-6">
                <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
                  <Clock size={20} />
                  Timeline
                </h3>
                
                <div className="space-y-6 relative before:absolute before:left-3.5 before:top-2 before:bottom-0 before:w-px before:bg-neutral-100">
                  {editingCustomer.timeline && editingCustomer.timeline.length > 0 ? (
                    editingCustomer.timeline.map((entry) => (
                      <div key={entry.id} className="relative pl-10">
                        <div className={`absolute left-0 top-0 w-8 h-8 rounded-full border-4 border-white flex items-center justify-center ${
                          entry.type === 'status_change' ? 'bg-black text-white' :
                          entry.type === 'activity' ? 'bg-green-500 text-white' :
                          'bg-neutral-200 text-neutral-500'
                        }`}>
                          {entry.type === 'status_change' ? <AlertCircle size={12} /> : 
                           entry.type === 'activity' ? <Check size={12} /> : 
                           <MessageSquare size={12} />}
                        </div>
                        <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-100">
                          <p className="text-sm font-medium text-neutral-900">{entry.content}</p>
                          <div className="flex justify-between items-center mt-2 text-[10px] text-neutral-400">
                            <span>{entry.author}</span>
                            <span>{entry.date}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="pl-10 text-sm text-neutral-400 italic">No history recorded</div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Modals */}
          {showLostModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
              <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-xl">
                <h3 className="text-xl font-bold mb-4">Mark as Lost</h3>
                <p className="text-sm text-neutral-500 mb-4">Please provide a reason for marking this customer as lost.</p>
                <textarea 
                  className="w-full border border-neutral-200 rounded-xl p-3 text-sm mb-4 focus:outline-none focus:ring-2 focus:ring-black"
                  rows={3}
                  placeholder="Reason (e.g., Price, Competitor, Timing...)"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                />
                <div className="flex justify-end gap-2">
                  <button onClick={() => setShowLostModal(false)} className="px-4 py-2 text-sm font-bold text-neutral-500 hover:bg-neutral-50 rounded-lg">Cancel</button>
                  <button onClick={handleManualActionSubmit} className="px-4 py-2 text-sm font-bold bg-red-600 text-white rounded-lg hover:bg-red-700">Confirm Lost</button>
                </div>
              </div>
            </div>
          )}

          {showTransferModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
              <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-xl">
                <h3 className="text-xl font-bold mb-4">Transfer Customer</h3>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="text-xs font-bold text-neutral-500 block mb-1">Transfer To (Store/Person)</label>
                    <input 
                      type="text"
                      className="w-full border border-neutral-200 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      placeholder="e.g., Store B - John Doe"
                      value={transferTarget}
                      onChange={(e) => setTransferTarget(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-neutral-500 block mb-1">Reason / Notes</label>
                    <textarea 
                      className="w-full border border-neutral-200 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                      rows={2}
                      placeholder="Reason for transfer..."
                      value={actionReason}
                      onChange={(e) => setActionReason(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button onClick={() => setShowTransferModal(false)} className="px-4 py-2 text-sm font-bold text-neutral-500 hover:bg-neutral-50 rounded-lg">Cancel</button>
                  <button onClick={handleManualActionSubmit} className="px-4 py-2 text-sm font-bold bg-black text-white rounded-lg hover:bg-neutral-800">Confirm Transfer</button>
                </div>
              </div>
            </div>
          )}

        </div>
      );
    }


    return (
      <div className="space-y-6 max-w-5xl mx-auto">
        {/* Header Controls: Search, Filter, Tabs */}
        <div className="flex flex-col md:flex-row items-center gap-3 md:gap-4">
          
          {/* Search Input - Full width on mobile, fixed width on desktop */}
          <div className="relative w-full md:w-64 order-3 md:order-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={16} />
            <input 
              type="text" 
              placeholder="Search name or email..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-3 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-black text-sm font-medium bg-white shadow-sm"
            />
          </div>

          {/* Filter Button */}
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className={`order-1 md:order-2 flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-bold transition-all shrink-0 ${isFilterOpen ? 'bg-black text-white' : 'bg-white text-neutral-900 border border-neutral-200 hover:bg-neutral-50 shadow-sm'}`}
          >
            <Filter size={16} />
            <span className="hidden sm:inline">Filters</span>
            {(selectedTags.length > 0 || selectedResults.length > 0 || selectedSources.length > 0) && (
              <span className="bg-neon-lime text-black text-[10px] w-5 h-5 rounded-full flex items-center justify-center">
                {selectedTags.length + selectedResults.length + selectedSources.length}
              </span>
            )}
          </button>

          {/* Stage Tabs */}
          <div className="order-2 md:order-3 flex-1 overflow-hidden relative group w-full md:w-auto">
             {/* Fade Mask for Scrolling */}
             <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-surface-grey to-transparent z-10 pointer-events-none md:hidden"></div>
             
             <div className="overflow-x-auto scrollbar-hide pr-8 md:pr-0">
                <div className="flex min-w-max bg-white rounded-xl shadow-sm border border-neutral-100 p-1">
                  {(['all', 'new_leads', 'qualified', 'converted', 'closing'] as (Stage | 'all')[]).map((stage) => {
                    const isActive = activeStage === stage;
                    const count = MOCK_CUSTOMERS.filter(c => stage === 'all' || c.stage === stage).length;
                    
                    return (
                      <button
                        key={stage}
                        onClick={() => setActiveStage(stage)}
                        className={`relative px-4 md:px-6 py-2.5 flex items-center gap-2 transition-all group ${isActive ? 'z-10' : 'z-0'}`}
                      >
                        {/* Arrow Shape Background */}
                        <div className={`absolute inset-0 transform skew-x-12 border-r border-white/50 transition-colors ${isActive ? 'bg-black' : 'bg-neutral-50 group-hover:bg-neutral-100'}`}></div>
                        
                        <span className={`relative z-10 text-xs md:text-sm font-bold uppercase tracking-wide ${isActive ? 'text-white' : 'text-neutral-500'}`}>
                          {stage.replace('_', ' ')}
                        </span>
                        <span className={`relative z-10 text-xs font-bold px-1.5 py-0.5 rounded-md ${isActive ? 'bg-white/20 text-white' : 'bg-neutral-200 text-neutral-600'}`}>
                          {count}
                        </span>
                      </button>
                    );
                  })}
                </div>
             </div>
          </div>

        </div>

        {/* Filter Panel */}
        {isFilterOpen && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-100 animate-in slide-in-from-top-2 fade-in duration-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-sm uppercase tracking-wide text-neutral-500">Filter Options</h3>
              <button onClick={() => { setSelectedTags([]); setSelectedResults([]); setSelectedSources([]); }} className="text-xs font-bold text-red-500 hover:text-red-700">Reset All</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-xs font-bold text-neutral-900 mb-2 block">Lead Source</label>
                <div className="flex flex-wrap gap-2">
                  {LEAD_SOURCES.filter(s => role === 'Dealership' || s !== 'Outbound').map(source => (
                    <button
                      key={source}
                      onClick={() => toggleFilterSource(source)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${selectedSources.includes(source) ? 'bg-black text-white border-black' : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'}`}
                    >
                      {source}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-900 mb-2 block">Activity Tags</label>
                <div className="flex flex-wrap gap-2">
                  {ALL_TAGS.map(tag => (
                    <button
                      key={tag}
                      onClick={() => toggleFilterTag(tag)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${selectedTags.includes(tag) ? 'bg-black text-white border-black' : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'}`}
                    >
                      {tag.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-neutral-900 mb-2 block">Results</label>
                <div className="flex flex-wrap gap-2">
                  {(['new', 'in_process', 'transferred', 'won', 'lost'] as Result[]).map(result => (
                    <button
                      key={result}
                      onClick={() => toggleFilterResult(result)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${selectedResults.includes(result) ? 'bg-black text-white border-black' : 'bg-white text-neutral-600 border-neutral-200 hover:border-neutral-400'}`}
                    >
                      {result.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Customer List */}
        <div className="grid grid-cols-1 gap-4">
          {filteredCustomers.length === 0 ? (
            <div className="text-center py-12 text-neutral-400">
              <Search size={48} className="mx-auto mb-4 opacity-20" />
              <p>No customers found matching criteria.</p>
            </div>
          ) : (
            filteredCustomers.map(customer => (
              <div 
                key={customer.id}
                onClick={() => setSelectedCustomer(customer)}
                className="bg-white p-5 rounded-2xl shadow-sm border border-neutral-100 hover:shadow-md hover:border-neutral-200 transition-all cursor-pointer group"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-neutral-100 flex items-center justify-center font-bold text-neutral-500 group-hover:bg-black group-hover:text-white transition-colors">
                      {customer.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-neutral-900">{customer.name}</h4>
                      <div className="text-xs text-neutral-500 flex items-center gap-2">
                        <span>{customer.vehicleInterest}</span>
                        <span className="w-1 h-1 bg-neutral-300 rounded-full"></span>
                        <span>{customer.lastContact}</span>
                      </div>
                    </div>
                  </div>
                  <ChevronRight size={20} className="text-neutral-300 group-hover:text-black transition-colors" />
                </div>
                
                <div className="mt-4 flex flex-wrap gap-2 items-center">
                   {/* Result Badge */}
                   <span className={`text-[10px] font-bold px-2 py-1 rounded-md border uppercase ${
                      customer.result === 'won' ? 'bg-green-50 text-green-700 border-green-100' :
                      customer.result === 'lost' ? 'bg-red-50 text-red-700 border-red-100' :
                      customer.result === 'transferred' ? 'bg-orange-50 text-orange-700 border-orange-100' :
                      'bg-neutral-100 text-neutral-600 border-neutral-200'
                    }`}>
                      {customer.result.replace('_', ' ')}
                    </span>
                    
                    <div className="h-4 w-px bg-neutral-200 mx-1"></div>
                    
                    {/* Active Tags Summary */}
                    {customer.tags.length > 0 ? (
                      customer.tags.slice(0, 3).map(tag => (
                        <span key={tag} className="flex items-center gap-1 text-[10px] font-medium px-2 py-1 rounded-md bg-green-50 text-green-700 border border-green-100">
                          <Check size={10} />
                          {tag.replace('_', ' ')}
                        </span>
                      ))
                    ) : (
                      <span className="text-[10px] text-neutral-400 italic">No activity yet</span>
                    )}
                    {customer.tags.length > 3 && (
                      <span className="text-[10px] text-neutral-400">+{customer.tags.length - 3} more</span>
                    )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'my_actions':
        return <SalesDashboard role={role} userName={userName} />;
      case 'profile':
        return renderProfileContent();
      case 'Connect':
        return <ConnectView role={role} userName={userName} userTitle={role === 'D2C' ? 'Client Advisor' : 'Sales Consultant'} />;
      case 'Configuration':
      case 'Test Drive':
      case 'Order & Delivery':
      case 'Deal Builder':
        return (
          <div className="flex flex-col items-center justify-center h-full text-neutral-400 space-y-4">
             <div className="w-20 h-20 rounded-full bg-neutral-100 flex items-center justify-center">
               <BookOpen size={32} />
             </div>
             <div className="text-center">
               <h3 className="text-lg font-bold text-neutral-900">{activeTab}</h3>
               <p className="font-medium">Workflow Step Details</p>
             </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <UnifiedOverlayLayout
      title="Store Sales"
      roleSwitcher={<RoleSwitcher />}
      avatarPanel={<AvatarPanel />}
      workflowOptions={['Connect', 'Configuration', 'Test Drive', 'Order & Delivery', 'Deal Builder']}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onGoHome={onGoHome}
    >
      {renderContent()}
    </UnifiedOverlayLayout>
  );
}

function ActionCard({ icon, label, count, description }: { icon: React.ReactNode, label: string, count: number, description: string }) {
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-100 flex items-center justify-between group cursor-pointer hover:shadow-md transition-all">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-neutral-50 flex items-center justify-center group-hover:bg-neutral-100 transition-colors">
          {icon}
        </div>
        <div>
          <h4 className="font-bold text-neutral-900">{label}</h4>
          <p className="text-sm text-neutral-500">{description}</p>
        </div>
      </div>
      <span className="bg-neutral-900 text-white text-sm font-bold px-3 py-1 rounded-full">
        {count}
      </span>
    </div>
  );
}

function MetricRow({ label, value, highlight }: { label: string, value: string, highlight?: boolean }) {
  return (
    <div className="flex justify-between items-center p-2 hover:bg-neutral-50 rounded-lg transition-colors">
      <span className="text-sm text-neutral-500">{label}</span>
      <span className={`font-bold ${highlight ? 'text-green-600' : 'text-neutral-900'}`}>{value}</span>
    </div>
  );
}

function ModuleCard({ title, icon, children, isActive }: { title: string, icon: React.ReactNode, children: React.ReactNode, isActive: boolean }) {
  const [isExpanded, setIsExpanded] = useState(isActive);

  return (
    <div className={`bg-white rounded-2xl border transition-all duration-300 overflow-hidden ${isActive ? 'border-neutral-200 shadow-sm' : 'border-neutral-100 opacity-80'}`}>
      <div 
        className={`p-4 flex items-center justify-between cursor-pointer ${isActive ? 'bg-neutral-50' : 'bg-white'}`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isActive ? 'bg-black text-white' : 'bg-neutral-100 text-neutral-400'}`}>
            {icon}
          </div>
          <h3 className={`font-bold text-sm ${isActive ? 'text-neutral-900' : 'text-neutral-400'}`}>{title}</h3>
        </div>
        <div className="flex items-center gap-2">
          {isActive && <span className="text-[10px] font-bold uppercase bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Active</span>}
          <ChevronRight size={16} className={`text-neutral-400 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
        </div>
      </div>
      {isExpanded && (
        <div className="p-4 border-t border-neutral-100 animate-in slide-in-from-top-2 fade-in duration-200">
          {children}
        </div>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string, value: string }) {
  return (
    <div>
      <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-0.5">{label}</span>
      <div className="text-sm font-medium text-neutral-900 border-b border-neutral-100 pb-1">{value}</div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="text-center py-4 text-neutral-400 text-xs italic bg-neutral-50 rounded-lg border border-dashed border-neutral-200">
      {text}
    </div>
  );
}
