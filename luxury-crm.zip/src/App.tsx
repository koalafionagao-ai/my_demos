import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Screen1Home } from './screens/Screen1Home';
import { Screen2StoreSales } from './screens/Screen2StoreSales';
import { Screen3StoreManager } from './screens/Screen3StoreManager';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState(1);
  const [selectedRole, setSelectedRole] = useState<'D2C' | 'Dealership'>('D2C');

  const handleNavigate = (screenId: number, role?: 'D2C' | 'Dealership') => {
    if (role) setSelectedRole(role);
    setCurrentScreen(screenId);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 1:
        return <Screen1Home onNavigate={handleNavigate} />;
      case 2:
        return <Screen2StoreSales initialRole={selectedRole} onGoHome={() => setCurrentScreen(1)} />;
      case 3:
        return <Screen3StoreManager initialRole={selectedRole} onGoHome={() => setCurrentScreen(1)} />;
      case 4:
        return <div className="p-8 text-center text-slate-500">Screen 4: OEM HQ - Region Manager (Coming Soon)</div>;
      case 5:
        return <div className="p-8 text-center text-slate-500">Screen 5: OEM HQ - Executive (Coming Soon)</div>;
      default:
        return <Screen1Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <Layout currentScreen={currentScreen} onScreenChange={setCurrentScreen}>
      {renderScreen()}
    </Layout>
  );
}
